/**
 * 
 */
/**
 * 
 */
module PRODUTTORE_CONSUMATORE {
}