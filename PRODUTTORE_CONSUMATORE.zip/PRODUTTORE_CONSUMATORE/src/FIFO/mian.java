package FIFO;


import java.util.Scanner;


public class mian {

	public static void main(String[] args) {
		 int a;
		 
		
		Scanner in = new Scanner(System.in);
		System.out.println("inserisci numero thread");
		a=in.nextInt();
		
		
		buffer buffer = new buffer();
		
		Thread[]arr = new Thread[a];
		
		for(int i =0;i<a;i++) {	
				Thread t = new Thread(buffer);
				arr[i]=t;
				arr[i].start();
			}

	}

}

