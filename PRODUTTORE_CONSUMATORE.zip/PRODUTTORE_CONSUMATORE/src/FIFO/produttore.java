package FIFO;
import java.util.Random;

public class produttore {
	private  Random random = new Random();
	
	private int numerocasuale;
	
	produttore(){
	
		
	}
	
	public synchronized int generanumero(int index) {
		numerocasuale = random.nextInt(1023);
		System.out.println("HO INSERITO IL NUMERO: "+numerocasuale);
		if(index==10)
			try {
				Thread.currentThread().wait();
				index=index--;
				return index;
			} catch (InterruptedException e) {
				e.printStackTrace();
				
			}
		return numerocasuale;
		
	}


}
