package FIFO;

public class consumatore {

	
consumatore(){
	
		
	}
	
	public synchronized void prelevanumero(int a) {
		Thread.currentThread().notify();
		System.out.println("HO PRESO IL NUMERO: "+a);
		
	}

}
