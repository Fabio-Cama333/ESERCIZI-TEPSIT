package FIFO;

import java.util.Random;

public class buffer implements Runnable {

	private int[] buffer;
	private produttore produttore;
	private consumatore consumatore;
	Random random = new Random();
	int sceltacasuale;
	int n;
	int indexaggiungi;
	int indexrimuovi;
	
	buffer(){
		 buffer = new int[10];//grandezza scelta da me
		 produttore = new produttore();
		 consumatore = new consumatore();
		 
		 indexaggiungi=0;
		 indexrimuovi =0;
	}
	
	
	public void run() {
		 sceltacasuale= random.nextInt(2);
		 
		if(sceltacasuale == 1) {
			n=produttore.generanumero(indexaggiungi);
			if(indexaggiungi==10)
				indexaggiungi=produttore.generanumero(indexaggiungi);
			buffer[indexaggiungi]=n;
			indexaggiungi++;
		}else {
			consumatore.prelevanumero(buffer[indexrimuovi]);
			indexrimuovi++;
			
		}

	}

}
