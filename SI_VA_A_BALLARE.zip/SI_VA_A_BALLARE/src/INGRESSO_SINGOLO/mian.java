package INGRESSO_SINGOLO;

public class mian {

	public static void main(String[] args) {
		 entrata entrata = new entrata();
	        int Persone = 10;  // Numero di persone

	        // Crea e avvia i thread
	        for (int i = 0; i < Persone; i++) {
	            new contatore(entrata);
	        }

	        // Monitoraggio dello stato della discoteca ogni secondo
	        while (true) {
	            try {
	                Thread.sleep(1000);  // Attende 1 secondo
	                System.out.println("Persone dentro la discoteca: " + entrata.getNumeroPersoneDentro());
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }


	}

}
