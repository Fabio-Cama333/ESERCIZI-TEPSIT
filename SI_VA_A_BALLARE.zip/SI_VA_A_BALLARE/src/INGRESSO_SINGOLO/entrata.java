package INGRESSO_SINGOLO;

public class entrata {
	 private int personeDentro = 0;

	    // Aggiunge una persona
	    public synchronized void entra() {
	        personeDentro++;
	    }

	    // Rimuove una persona
	    public synchronized void esce() {
	        personeDentro--;
	    }

	    // Restituisce il numero di persone all'interno
	    public synchronized int getNumeroPersoneDentro() {
	        return personeDentro;
	    }

}
