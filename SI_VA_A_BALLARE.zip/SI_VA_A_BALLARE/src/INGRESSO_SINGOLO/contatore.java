package INGRESSO_SINGOLO;
import java.util.Random;
public class contatore implements Runnable {

	
	
		private entrata entrata;
	    private Random random;

	    contatore(entrata e) {
	        entrata = e;
	        this.random = new Random();
	    }

	    @Override
	    public void run() {
	        try {
	            while (true) {
	                // La persona entra nella discoteca
	                entrata.entra();

	                // La persona resta nella discoteca per un tempo casuale (da 1 a 5 secondi)
	                Thread.sleep(random.nextInt(5000) + 1000);

	                // La persona esce dalla discoteca
	                entrata.esce();

	                // La persona resta fuori per un tempo casuale (da 1 a 5 secondi)
	                Thread.sleep(random.nextInt(5000) + 1000);
	            }
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    

	}

}

