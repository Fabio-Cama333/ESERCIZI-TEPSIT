package Stato_Thread;

public class contatore implements Runnable {

	
	private int n;
	private int conta;
	long millis;
	contatore(int a){
		millis = 120;
		n=a;
		conta = 0;
	}
	public synchronized void run() {
		for(int i=0;i<n;i++) {
			try {

			Thread.currentThread().sleep(millis);
		
			}catch (Exception e) {}
			conta=i;
		
		
				
		
	}
	
	}
	
	public int getconta() {
		return conta;
	}
	
}
