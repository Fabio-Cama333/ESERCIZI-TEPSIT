package Stato_Thread;
import java.util.Scanner;
import java.util.Random;
public class main {

	public static void main(String[] args) {
		 int a;
		 Random random = new Random();
		int randomizer;
		 int n;
		 long millis = 1000;
		 int conta;
		
		Scanner in = new Scanner(System.in);
		System.out.println("inserisci numero thread");
		a=in.nextInt();
		System.out.println("inserisci numero fino a cui contare");
		n=in.nextInt();
		randomizer= random.nextInt(n);
		contatore c = new contatore(randomizer);
		Thread[]arr = new Thread[a];
		for(int i =0;i<a;i++) {	
			Thread t = new Thread(c);
			arr[i]=t;
			arr[i].start();
			try {

				Thread.currentThread().sleep(millis);
			
				}catch (Exception e) {}
			
			
			 
			 if(arr[i].isAlive()==false) {
				
						System.out.println(arr[i]+"terminato");
					
			 }else {
				 System.out.println(conta= c.getconta());
				 try {
			            arr[i].join(); 
			        } catch (InterruptedException e) {
			            e.printStackTrace();
			        }
				 
				
			 }
			
					
					
				
		 
			
		}
		System.out.println("TUTTI I THREAD SONO TERMINATI");
		
		
		
		

	}

}
